# URL Structure — invoxai.io

The complete routing map for the platform. Pairs with `FINAL-master-prompt.md` and `FULL-PLAN-CHECKLIST.md`.

---

## Platform domains

| Surface | URL |
|---|---|
| Main marketing website | `invoxai.io` |
| Seller dashboard | `app.invoxai.io` |
| Admin panel | `admin.invoxai.io` |
| `www` | redirect `www.invoxai.io` → `invoxai.io` |

---

## Seller public pages

These live on the seller's subdomain `name.invoxai.io`. The **same paths apply on a connected custom domain** (e.g. `mybrand.com/store`).

| Page type | Path | Instances per seller |
|---|---|---|
| Website (home) | `name.invoxai.io/` | one |
| Store | `name.invoxai.io/store` | one |
| Bio | `name.invoxai.io/bio` | one |
| Courses | `name.invoxai.io/courses` | one (course hub) |
| One-page product | `name.invoxai.io/opp/{id}` | many |
| Payment page | `name.invoxai.io/pay/{id}` | many |
| 1-to-1 booking | `name.invoxai.io/book/{id}` | many |
| Lead form | `name.invoxai.io/ldf/{id}` | many |
| VIP channel/group | `name.invoxai.io/vpc/{id}` | many |
| Landing page | `name.invoxai.io/led/{id}` | many |
| Event booking | `name.invoxai.io/env/{id}` | many |
| Checkout | `name.invoxai.io/{page_type}/checkout/{order_id}` | per order |

**Custom domain mapping:** once a seller connects `mybrand.com`, every path moves to it (`mybrand.com/store`, `mybrand.com/opp/{id}`, …) and the old `name.invoxai.io/...` URLs **301-redirect** to the custom domain.

---

## Checkout routing (page-type aware)

Checkout sits **under the page type** that started it, so the URL shows the source. The `{order_id}` resolves the exact product, amount, and seller from the database.

Pattern: `name.invoxai.io/{page_type}/checkout/{order_id}`

| From | Checkout URL |
|---|---|
| Store | `name.invoxai.io/store/checkout/{order_id}` |
| One-page product | `name.invoxai.io/opp/checkout/{order_id}` |
| Payment page | `name.invoxai.io/pay/checkout/{order_id}` |
| Courses | `name.invoxai.io/courses/checkout/{order_id}` |
| 1-to-1 booking | `name.invoxai.io/book/checkout/{order_id}` |
| VIP channel/group | `name.invoxai.io/vpc/checkout/{order_id}` |
| Event booking | `name.invoxai.io/env/checkout/{order_id}` |

(Bio, lead form, and landing pages have no direct checkout — a landing/bio CTA points to one of the paid page types above.)

---

## Routing recommendations (important)

1. **Reserve system subdomains** — block sellers from claiming these at signup:
   `app`, `admin`, `www`, `api`, `mail`, `smtp`, `ftp`, `cdn`, `assets`, `static`, `blog`, `help`, `support`, `status`, `ns1`, `ns2`, plus offensive/brand-conflict terms. If you skip this, someone could register `app.invoxai.io` and break your platform.

2. **Lowercase all paths** — normalize `/Courses` → `/courses`. URLs are case-sensitive; pick lowercase everywhere.

3. **Use short, random, non-sequential `{id}`s** — e.g. an 8–10 char nanoid (`opp/a7Bx9KmQ`), not `1, 2, 3`. Sequential numbers let anyone guess and crawl other sellers' pages. Optionally also allow a seller-chosen **custom slug** (e.g. `/opp/summer-sale`).

4. **Checkout is page-type aware + needs an order id** — `/{page_type}/checkout/{order_id}`. The page type gives you source attribution (which kind of page drove the sale); the `order_id` tells the page exactly what's being paid for (amount, product, seller, pixels).

5. **Pixels fire on every public path** — Meta + Google pixel injection applies to all the seller pages above, including checkout.

6. **Routing precedence** — fixed paths (`/store`, `/bio`, `/courses`, `/checkout`) take priority; prefixed dynamic routes (`/opp/`, `/pay/`, `/book/`, `/ldf/`, `/vpc/`, `/led/`, `/env/`) match their `{id}`.

---

## Note on two abbreviations
- `led` = landing page, `env` = event booking — kept exactly as you specified. (If you ever want clearer ones, `lp` and `evt` read more obviously — but no need to change; just flagging.)

---

## Path prefix reference

| Prefix | Meaning |
|---|---|
| `/opp/` | one-page product |
| `/pay/` | payment page |
| `/book/` | 1-to-1 booking |
| `/ldf/` | lead form |
| `/vpc/` | VIP premium channel/group |
| `/led/` | landing page |
| `/env/` | event booking |
| `/{page_type}/checkout/` | checkout, nested under its source page type (per order) |
