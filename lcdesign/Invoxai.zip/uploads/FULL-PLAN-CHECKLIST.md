# Full Plan — Complete Checklist

A complete, trackable list of everything in the platform. Check items off as you build. Pairs with `FINAL-master-prompt.md` (which explains *how* each works).

---

## A. Tech stack
- [ ] Supabase — Postgres DB, Auth (Google + Email OTP), Storage, Row Level Security, Edge Functions, cron
- [ ] Next.js app on Hostinger KVM2 VPS
- [ ] Caddy reverse proxy — auto SSL for wildcard subdomains + custom domains
- [ ] SSR + CDN for page speed
- [ ] Platform gateways: Razorpay + Cashfree
- [ ] Seller gateways: Razorpay, Cashfree, Stripe, PayU, PhonePe
- [ ] Transactional email service (e.g. SES) + seller brand email

## B. Architecture (lock in first)
- [ ] 3 surfaces: Seller dashboard, Buyer corner, Admin panel (one account system)
- [ ] 2 payment layers: platform billing vs seller payments (fully separate in code)
- [ ] 2 email layers: platform transactional vs seller marketing
- [ ] Supabase RLS isolating all three surfaces

## C. Auth & onboarding
- [ ] Google login
- [ ] Email OTP login
- [ ] Onboarding step 1: Email OTP verification
- [ ] Onboarding step 2: Store name
- [ ] Onboarding step 3: Subdomain (live availability check)
- [ ] Onboarding step 4: Business category (also sets commission rate)
- [ ] Onboarding step 5: Billing details
- [ ] Resume onboarding if incomplete; block dashboard until done

## D. Domains & subdomains
- [ ] Subdomain hosting (`name.yoursite.com`) — wildcard routing
- [ ] **1 subdomain included; extra subdomains paid** (price set in admin)
- [ ] Custom domain connect (CNAME + verify + Caddy SSL)
- [ ] **1 custom domain included; extra domains paid** (price set in admin)
- [ ] On domain connect: all subdomain projects auto-shift to custom domain
- [ ] Seller dashboard URLs update to custom domain
- [ ] Subdomain links 301-redirect to custom domain

## E. Seller — page building & blocks
- [ ] Template renderer + page builder
- [ ] Single page + multi-page website
- [ ] Bio / link-in-bio page
- [ ] One-page product
- [ ] Digital store (catalog, cart, checkout)
- [ ] Courses (modules/lessons, video hosting, access gating, progress)
- [ ] 1-to-1 booking (availability, slots, payment, confirmation)
- [ ] Event booking (tickets/seats, payment, attendee list)
- [ ] Payment page (standalone)
- [ ] Lead form (capture → CRM)
- [ ] VIP premium channel/group join (auto-grant after payment)
- [ ] Checkout / payment page (own template type)

## F. Seller — growth & data tools
- [ ] Abandoned cart recovery
- [ ] Upsell product options
- [ ] Discount/coupon codes (percentage or fixed amount; usage limits; expiry; scope by product/category)
- [ ] Discount links — a URL that auto-applies a coupon (e.g. `?coupon=CODE`)
- [ ] Coupon auto-applies across all payment pages (store, opp, pay, courses, book, vpc, env, and checkout)
- [ ] Coupon usage tracked in CRM + analytics
- [ ] SEO settings per page: meta title/description, slug, Open Graph + Twitter image, canonical, index/noindex, schema.org
- [ ] Platform SEO: auto sitemap.xml, robots.txt, SSR, mobile-friendly + fast, clean lowercase URLs
- [ ] CRM: customers, **pending-payment users**, all transactions, total spend, categories bought, search/filter/export
- [ ] Analytics dashboard (visitors, clicks, devices, sources)
- [ ] Meta + Google ad pixels on **every** page (including checkout)
- [ ] Page content editing/update on all pages (sections, text, media, colors, SEO, pixels, draft/preview/publish)

## G. Seller — payments & wallet
- [ ] Connect own gateway (receive from buyers)
- [ ] Platform checkout uses seller gateway keys + records every order
- [ ] Prepaid wallet: balance + recharge
- [ ] Per-sale commission auto-deducted (per-category rate)
- [ ] Full wallet transaction ledger (auditable)
- [ ] Low-balance restriction on selling
- [ ] Daily wallet-cut invoice (scheduled job + email)

## H. Seller — email marketing
- [ ] Email sending config: **Custom SMTP** (host/port/user/pass/encryption) OR **Google Mail** (Gmail address + App Password)
- [ ] "Send test email" verification
- [ ] Connect own brand email
- [ ] Marketing email templates
- [ ] Automation sequences
- [ ] Abandoned-cart recovery emails

## I. Buyer corner
- [ ] Login: Google + Email OTP
- [ ] Purchase history + order history
- [ ] Total spend
- [ ] Purchase date
- [ ] Product category bought
- [ ] Global identity keyed by email (orders across multiple sellers)

## J. Admin panel
- [ ] All active users + new-users-joined (count + trend)
- [ ] Buyer details
- [ ] Revenue dashboard (all 6 streams) + plan purchases
- [ ] Plan & feature editor (create/update price plans + features)
- [ ] Contact limit + overage config (₹10/extra — confirm)
- [ ] Per-category commission rate config
- [ ] Premium template pricing
- [ ] Plan promo / discount codes (for subscription purchases)
- [ ] **Extra subdomain pricing**
- [ ] **Extra custom domain pricing**
- [ ] Branding: logo, favicon, billing/invoice template
- [ ] Monitoring: platform health + user public-page health
- [ ] User activity / satisfaction
- [ ] Maintenance mode toggle
- [ ] Platform payment gateway: Razorpay + Cashfree
- [ ] Email config (platform): **Custom SMTP** OR **Google Mail** (Gmail + App Password) + send-test, encrypted storage
- [ ] Email automation control (all platform emails)

## K. Platform emails (transactional)
- [ ] OTP
- [ ] Verification
- [ ] Welcome (new user)
- [ ] Payment confirmation (plan purchase)
- [ ] Invoice (from billing template)
- [ ] Daily wallet invoice
- [ ] Weekly report

## L. Revenue model (6 streams)
- [ ] Subscription plans
- [ ] Per-sale commission (wallet, per-category)
- [ ] Contact overage (₹10/extra contact)
- [ ] Premium template sales
- [ ] Extra subdomains (1 included, extras paid)
- [ ] Extra custom domains (1 included, extras paid)

## M. Themes & templates
- [ ] Shared design system (tokens + components) — build first
- [ ] 100% modern, dynamic, ultra-premium design
- [ ] Fully responsive (mobile + web)
- [ ] Fast-loading
- [ ] Template sets per feature (bio, product, store, courses, booking, event, payment page, lead form, website)
- [ ] Checkout page template (clean, trustworthy, conversion-focused)
- [ ] Ad-pixel fields on all templates
- [ ] Launch: 3–5 flagship templates per core feature
- [ ] Grow toward 25+ per feature over time
- [ ] Mark premium templates as paid (price in admin)

## N. Critical rules & risks
- [ ] Scope discipline — build phase by phase, never two big modules at once
- [ ] Two payment layers kept fully separate
- [ ] Wallet ledger exact + auditable
- [ ] Supabase RLS correct from the start
- [ ] Encrypt gateway keys; confirm via webhooks; no card storage
- [ ] Reliable email deliverability (OTP, invoices)
- [ ] Page speed (SSR + CDN)

## O. Build order (phases)
- [ ] Foundation: Supabase schema + auth + RLS, transactional email (OTP), thin admin, Caddy subdomain SSL, onboarding, design system + first templates
- [ ] Phase 1 — Core MVP: templates + subdomain + bio + one-page product + lead form + pixels + analytics + Razorpay checkout + buyer corner v1 + platform email v1 + thin admin
- [ ] Phase 2 — Selling depth, wallet & billing: store, payment page, custom domains + auto-shift/redirect, wallet + commission + daily invoice, more gateways, platform billing full + plan/feature editor + contact overage + domain/subdomain pricing, invoices, CRM v1
- [ ] Phase 3 — Services, growth, fuller admin: courses, 1-to-1, events, abandoned cart, upsell, premium template marketplace, admin branding/health/activity, weekly reports
- [ ] Phase 4 — Community + seller email: VIP access, brand email + automation + templates
- [ ] Phase 5 — Growth: advanced analytics, A/B testing, 25+ templates, team/agency
